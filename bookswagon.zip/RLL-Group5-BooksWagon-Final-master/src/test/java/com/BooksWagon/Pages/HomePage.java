package com.BooksWagon.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class HomePage {

	@FindBy(xpath="//div[@class='col-sm-5 d-flex align-items-center justify-content-end']/descendant::span[3]")
	WebElement MyAccount;
	
	@FindBy(xpath="//div[@class='userpopup']/descendant::a[1]")
	WebElement LoginBtn;
	
	
	@FindBy(xpath = "/html/body/form/div[10]/div/div/div/div/div/div[5]/div")
	WebElement yourAddress;
	
	
	@FindBy(linkText = "Request a Book")
	WebElement requestButton;
	
	
	
	
	public HomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		
	}
	public void	clickLogin(WebDriver driver) throws InterruptedException {
		
		Actions a = new Actions(driver);
		a.moveToElement(MyAccount).perform();
		Thread.sleep(1500);
		
		LoginBtn.click();
		
	}
	
	
	 public void click_RequestBook() {		
	    	requestButton.click();
	        
	    }
	 
	
	 

}
