package com.BooksWagon.StepDefinition;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;

import com.github.dockerjava.transport.DockerHttpClient.Request.Method;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class SharedSteps {
	
	public static WebDriver driver;
	@Before
	public void setup() 
	{	
		driver = new ChromeDriver();
		driver.get("https://www.bookswagon.com/");
		driver.manage().window().maximize();
	}
	
	public WebDriver getDriver() 
	{
		return driver;
	}
	//@After
	public void tearDown() {
		driver.close();
	}
	
}
