package com.BooksWagon.Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features=
						"C:\\Users\\Administrator\\Desktop\\RLL-Group5-BooksWagon-Final-master\\src\\test\\resources\\RequestABook.feature",
						
				glue= {"com.BooksWagon.StepDefinition"},
				dryRun=false,
						plugin={"pretty",
								"html:target/myreport4.html",
								  "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
								  "timeline:test-output-thread/"}
)
public class TestRunner2 extends AbstractTestNGCucumberTests {

}
